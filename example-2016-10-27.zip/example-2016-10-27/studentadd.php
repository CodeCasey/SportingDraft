<?php
require 'dbconnect.php';
$sql = "insert into students (firstname,lastname,email) VALUES ('" . $_REQUEST["firstname"] .
  "','" . $_REQUEST["lastname"] . "','" . $_REQUEST["email"] . "')";

if (!$result = $mysqli->query($sql)) {
    echo "Error: Query error, here is why: </br>";
    echo "Errno: " . $mysqli->errno . "</br>";
    echo "Error: " . $mysqli->error . "</br>";
    exit;
}

?>

<script>
window.location = 'studentlist.php';
</script>