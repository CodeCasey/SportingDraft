<form action="classadd.php">
  Department:
 <select name="department">
     <?php
         require 'deptopts.php';
     ?>
  </select>
  <br>
  Number:
  <input type="text" name="number" >
  <br>
  Name:
  <input type="text" name="name" >
  <br>

  <input type="submit" value="Submit">
</form>