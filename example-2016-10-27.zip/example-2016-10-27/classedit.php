<form action="classup.php">
  Department:
  <select name="department">
     <?php
         require 'deptopts.php';
     ?>
  </select>
  
  <br>
  Number:
  <input type="text" name="number" value="<?php echo substr($_REQUEST["id"],4) ?>">
  <br>
  Name:
  <input type="text" name="name" value="<?php echo $_REQUEST["name"] ?>">
  <br>
  <input type="hidden" name="id" value="<?php echo $_REQUEST["id"] ?>">
  <input type="submit" value="Submit">
</form>

<?php
require 'reglist.php';
?>