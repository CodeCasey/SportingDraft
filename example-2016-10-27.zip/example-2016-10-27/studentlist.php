<?php
require 'menu.php';

require 'dbconnect.php';

$sql = "SELECT * FROM students";
if (!$result = $mysqli->query($sql)) {
    echo "Error: Query error, here is why: </br>";
    echo "Errno: " . $mysqli->errno . "</br>";
    echo "Error: " . $mysqli->error . "</br>";
    exit;
}
echo "<table border=1><th>First Name</th><th>Last Name</th><th>Email</th><th>Operations</th>";
while($student = $result->fetch_assoc())
   echo "<tr><td>" . $student["firstname"] . "</td><td>" . $student["lastname"] .
      "</td><td>" .$student["email"] . 
      "</td><td><a href='studentdelete.php?id=" . $student["id"] . "'>Del</a> " .
      "<a href='studentedit.php?id=" . $student["id"] . "&firstname=" . $student["firstname"] .
      "&lastname=" . $student["lastname"] . 
      "&email=" . $student["email"] . 
      "'>Edit</a>" .
      "</td></tr>";
echo "</table>";

?>
<a href='studentadd.htm'>Add a Student</a>