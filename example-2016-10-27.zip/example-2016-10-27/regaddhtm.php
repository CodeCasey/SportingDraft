<form action="regadd.php">
  Department:
 <select name="department">
     <?php
         require 'deptopts.php';
     ?>
  </select>
  <br>
  Number:
  <input type="text" name="number" >
  <br>
  Student:
  <select name="studentid" >
     <?php         
          require 'studentopts.php';
     ?>
  </select>
  <br>

  <input type="submit" value="Submit">
</form>