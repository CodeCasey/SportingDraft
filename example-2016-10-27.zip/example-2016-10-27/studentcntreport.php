<?php
require 'menu.php';
require 'dbconnect.php';

$sql = "SELECT * FROM coursecountbystudent";
if (!$result = $mysqli->query($sql)) {
    echo "Error: Query error, here is why: </br>";
    echo "Errno: " . $mysqli->errno . "</br>";
    echo "Error: " . $mysqli->error . "</br>";
    exit;
}
echo "<table border=1><th>Last Name</th><th>First Name</th><th>Enrollments</th>";
while($student = $result->fetch_assoc()) {
   echo "<tr><td>";
   if($student["lastname"] == "Total") echo "<b>";  
   echo $student["lastname"] . "</td><td>" . $student["student"] .
      "</td><td>" .$student["cnt"]; 
   if($student["lastname"] == "Total") echo "</b>";  

   echo "</td></tr>"; 
}
echo "</table>";

?>
