<?php
require 'dbconnect.php';
$sql = "insert into classes (department,number,name) VALUES ('" . $_REQUEST["department"] .
  "','" . $_REQUEST["number"] . "','" . $_REQUEST["name"] . "')";

if (!$result = $mysqli->query($sql)) {
    echo "Error: Query error, here is why: </br>";
    echo "Errno: " . $mysqli->errno . "</br>";
    echo "Error: " . $mysqli->error . "</br>";
    exit;
}

?>

<script>
window.location = 'classlist.php';
</script>