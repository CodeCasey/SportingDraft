<a href="classlist.php">Classes</a>
<a href="studentlist.php">Students</a>
<a href="classcntreport.php">Class Enrollments</a>
<a href="studentcntreport.php">Student Enrollments</a>