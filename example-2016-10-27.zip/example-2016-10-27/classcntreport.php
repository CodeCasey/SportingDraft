<?php
require 'menu.php';

require 'dbconnect.php';

$sql = "SELECT * FROM studentcountsbycourse";
if (!$result = $mysqli->query($sql)) {
    echo "Error: Query error, here is why: </br>";
    echo "Errno: " . $mysqli->errno . "</br>";
    echo "Error: " . $mysqli->error . "</br>";
    exit;
}
echo "<table border=1><th>Class Department</th><th>Class Number</th><th>Enrollment</th>";
while($student = $result->fetch_assoc())
   echo "<tr><td>" . $student["classdepartment"] . "</td><td>" . $student["classnumber"] .
      "</td><td>" .$student["cnt"] . "</td></tr>";
echo "</table>";

?>
