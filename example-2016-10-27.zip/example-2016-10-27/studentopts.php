<?php
require 'dbconnect.php';

$sql = "SELECT * FROM students order by lastname,firstname";
if (!$result = $mysqli->query($sql)) {
    echo "Error: Query error, here is why: </br>";
    echo "Errno: " . $mysqli->errno . "</br>";
    echo "Error: " . $mysqli->error . "</br>";
    exit;
}
while($student = $result->fetch_assoc()) {
//  
 echo "<option ";
 if($_REQUEST["studentid"] == $student["id"])
   echo "selected "; 
 echo "value='" . $student["id"] . "'>" . $student["firstname"] . " " . $student["lastname"] .
      "</option>";
}
?>
