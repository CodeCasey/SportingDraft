<?php
require 'dbconnect.php';

$sql = "SELECT * FROM roster ";
if (!empty($_REQUEST["firstname"]))
{
   // we are included in student edit
   $sql .= "where studentid = " . $_REQUEST["id"];
}
else
{
   // we are included in class edit
   $sql .= "where classdepartment = '" . substr($_REQUEST["id"],0,4) . 
     "' and classnumber = " .        substr($_REQUEST["id"],4);
}

if (!$result = $mysqli->query($sql)) {
    echo "Error: Query error, here is why: </br>";
    echo "Errno: " . $mysqli->errno . "</br>";
    echo "Error: " . $mysqli->error . "</br>";
    exit;
}
echo "<table border=1><th>First Name</th><th>Last Name</th><th>Class</th><th>Operations</th>";
while($reg = $result->fetch_assoc()) {
   $id = $reg["department"] . "-" . $reg["number"] . "-" . $reg[studentid];
   echo "<tr><td>" . $reg["firstname"] . "</td><td>" . $reg["lastname"] .
      "</td><td><a href='classedit.php?id=" . $reg[classdepartment] . $reg[classnumber] . "&name=" . $reg["classname"] . "'>" .$reg["classname"] . "</a>" .
      "</td><td><a href='regdelete.php?id=" . $id . "'>Del</a> " .
      "</td></tr>";
}
echo "</table>";

?>
<a href='regaddhtm.php'>Register a Student</a>