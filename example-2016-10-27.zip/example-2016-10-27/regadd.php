<?php
require 'dbconnect.php';

$sql = "call register(" . $_REQUEST["studentid"] . ",'" .$_REQUEST["department"] .
  "'," . $_REQUEST["number"] . ",@x)";
die($sql);

if (!$result = $mysqli->query($sql)) {
    echo "Error: Query error, here is why: </br>";
    echo "Errno: " . $mysqli->errno . "</br>";
    echo "Error: " . $mysqli->error . "</br>";
    exit;
}

$sql = "SELECT @x status";
if (!$result = $mysqli->query($sql)) {
    echo "Error: Query error, here is why: </br>";
    echo "Errno: " . $mysqli->errno . "</br>";
    echo "Error: " . $mysqli->error . "</br>";
    exit;
}
$status = $result->fetch_assoc();
if($status["status"] == "Sold Out!") {
  echo "Sorry, there are already too many students in the class.  Please choose another:)";
  exit;
}
?>

<script>
window.location = 'classlist.php';
</script>