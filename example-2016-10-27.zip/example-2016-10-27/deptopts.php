<?php
require 'dbconnect.php';

$sql = "SELECT * FROM department order by name";
if (!$result = $mysqli->query($sql)) {
    echo "Error: Query error, here is why: </br>";
    echo "Errno: " . $mysqli->errno . "</br>";
    echo "Error: " . $mysqli->error . "</br>";
    exit;
}
while($dept = $result->fetch_assoc()) {
//  
 echo "<option ";
 if(substr($_REQUEST["id"],0,4) == $dept["department"])
   echo "selected "; 
 echo "value='" . $dept["department"] . "'>" . $dept["name"] .
      "</option>";
}
?>
