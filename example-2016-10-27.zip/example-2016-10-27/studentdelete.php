<?php
require 'dbconnect.php';

$sql = "DELETE FROM students where id = " . $_REQUEST["id"];
if (!$result = $mysqli->query($sql)) {
    echo "Error: Query error, here is why: </br>";
    echo "Errno: " . $mysqli->errno . "</br>";
    echo "Error: " . $mysqli->error . "</br>";
    exit;
}

?>

<script>
window.location = 'studentlist.php';
</script>