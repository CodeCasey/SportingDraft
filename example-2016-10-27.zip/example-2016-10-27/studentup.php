<?php
require 'dbconnect.php';
$sql = "update students "; 
$sql .= "set firstname = '" . $_REQUEST["firstname"] . "',"; 
$sql .= "lastname = '" . $_REQUEST["lastname"] . "',";
$sql .= "email = '" . $_REQUEST["email"] . "' ";
$sql .= "where id = " . $_REQUEST["id"];
 
if (!$result = $mysqli->query($sql)) {
    echo "Error: Query error, here is why: </br>";
    echo "Errno: " . $mysqli->errno . "</br>";
    echo "Error: " . $mysqli->error . "</br>";
    exit;
}

?>

<script>
window.location = 'studentlist.php';
</script>