<?php
require 'menu.php';
require 'dbconnect.php';

$sql = "SELECT * FROM classes";
if (!$result = $mysqli->query($sql)) {
    echo "Error: Query error, here is why: </br>";
    echo "Errno: " . $mysqli->errno . "</br>";
    echo "Error: " . $mysqli->error . "</br>";
    exit;
}
echo "<table border=1><th>Department</th><th>Number</th><th>Name</th><th>Operations</th>";
while($class = $result->fetch_assoc()) {
   $id = $class["department"] . $class["number"];
   echo "<tr><td>" . $class["department"] . "</td><td>" . $class["number"] .
      "</td><td>" .$class["name"] . 
      "</td><td><a href='classdelete.php?id=" . $id . "'>Del</a> " .
      "<a href='classedit.php?id=" . $id . "&name=" . $class["name"] .
      "'>Edit</a>" .
      "</td></tr>";
}
echo "</table>";

?>
<a href='classaddhtm.php'>Add a Class</a>