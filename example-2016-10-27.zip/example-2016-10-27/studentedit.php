<form action="studentup.php">
  First name:
  <input type="text" name="firstname" value="<?php echo $_REQUEST["firstname"] ?>">
  <br>
  Last name:
  <input type="text" name="lastname" value="<?php echo $_REQUEST["lastname"] ?>">
  <br>
  Email:
  <input type="email" name="email" value="<?php echo $_REQUEST["email"] ?>">
  <br>
  <input type="hidden" name="id" value="<?php echo $_REQUEST["id"] ?>">
  <input type="submit" value="Submit">
</form>

<?php
require 'reglist.php';
?>