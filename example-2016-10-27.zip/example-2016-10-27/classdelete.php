<?php
require 'dbconnect.php';

$sql = "DELETE FROM classes where department = '" . substr($_REQUEST["id"],0,4) . "' and number = " . substr($_REQUEST["id"],4);
if (!$result = $mysqli->query($sql)) {
    echo "Error: Query error, here is why: </br>";
    echo "Errno: " . $mysqli->errno . "</br>";
    echo "Error: " . $mysqli->error . "</br>";
    exit;
}

?>

<script>
window.location = 'classlist.php';
</script>